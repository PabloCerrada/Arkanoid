Pablo Cerrada Vega
Francisco Miguel Galv�n Mu�oz

La manera de guardar no es la indicada
Deja algo de basura